@echo off
title EmailSentinelPet Setup
echo ============================================
echo   EmailSentinelPet desktop maid - setup
echo ============================================
echo.
echo Installing autostart, desktop shortcut and starting the maid...
echo (The maid herself will guide you through login with bubbles.)
echo.
copy /Y "%~dp0app\EmailSentinel.vbs" "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\" >nul
copy /Y "%~dp0app\pet_launch.vbs" "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\EmailSentinelPet.vbs" >nul
schtasks /Create /TN "EmailSentinelPetWatch" /TR "wscript.exe \"%~dp0app\watchdog.vbs\"" /SC MINUTE /MO 2 /F >nul
wscript "%~dp0app\create_shortcut.vbs"
wscript "%~dp0app\pet_launch.vbs"
echo.
echo DONE! The maid will appear and ask you for the license key and
echo account info in speech bubbles. Right-click her - Dialog to reply.
echo.
pause
