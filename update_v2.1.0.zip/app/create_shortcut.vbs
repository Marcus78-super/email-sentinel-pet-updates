' create_shortcut.vbs - desktop shortcut with maid icon (runs from app dir)
Dim fso, sh, appDir
Set fso = CreateObject("Scripting.FileSystemObject")
appDir = fso.GetParentFolderName(WScript.ScriptFullName)
Set sh = CreateObject("Wscript.Shell")
Dim desktop
desktop = sh.SpecialFolders("Desktop")
Set lnk = sh.CreateShortcut(desktop & "\EmailSentinelPet.lnk")
lnk.TargetPath = "wscript.exe"
lnk.Arguments = """" & appDir & "\pet_launch.vbs"""
lnk.WorkingDirectory = appDir
lnk.IconLocation = appDir & "\assets\logo.ico"
lnk.Description = "EmailSentinelPet maid"
lnk.Save
