@echo off
title EmailSentinelPet - TEST MODE
echo ============================================
echo   TEST MODE: run without installing anything
echo   (uses port 3090, your main maid stays safe)
echo ============================================
echo.
echo Starting test maid on port 3090...
echo (If this is a fresh copy, she will guide you through login.)
echo.
set EMAILSENTINEL_PORT=3090
start "" "%~dp0runtime\python\pythonw.exe" "%~dp0app\pet_server.pyc"
start "" "%~dp0runtime\python\pythonw.exe" "%~dp0app\sentinel.pyc"
ping -n 3 127.0.0.1 >nul
set ELECTRON_RUN_AS_NODE=
set DSH_PET_CONFIG_URL=http://127.0.0.1:3090/dsh-pet-7340/config
set DSH_PET_PETS=[{"id":"main","size":300}]
set DSH_PET_OPEN_TARGET=web
set DSH_PET_SITE_URL=https://www.deepseek.com
set DSH_PET_SCALE=1
ping -n 2 127.0.0.1 >nul
start "" "%~dp0runtime\electron\electron.exe" "%~dp0app\pet_helper"
echo.
echo The TEST maid should appear at the top-right of your desktop.
echo To stop and reset her, double-click reset-test.bat
echo (closing this window does NOT stop her)
pause
