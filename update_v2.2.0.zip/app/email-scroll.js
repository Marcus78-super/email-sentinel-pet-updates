// 近期计划卷轴：女仆从口袋掏出卷轴，三页签——📧邮件 / ⏰待办 / 📝每日计划
// 新邮件自动展开；待办显示倒计时；每日计划可添加/打勾/删除；8 秒轮询
(function () {
  'use strict';
  var el = null;
  var body = null;
  var lastNewest = null;
  var posTimer = null;
  var viewMode = 'mails'; // 'mails' | 'cal' | 'plans' | 'translate'
  var calSub = 'active'; // 待办子页：'active' 未完成 | 'done' 已完成
  var lastView = 'mails';
  var closedIds = {};
  var base = (typeof BASE !== 'undefined' && BASE) ? BASE : 'http://127.0.0.1:3080/dsh-pet-7340';
  window.__emailScrollOpen = false;

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function post(path, data, cb) {
    try {
      fetch(base + path, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data || {})
      }).then(function () { if (cb) cb(); }).catch(function () {});
    } catch (e) { /* ignore */ }
  }

  function leftText(start) {
    var left = (start - Date.now() / 1000);
    if (left < 0) return '已到';
    if (left < 3600) return '剩 ' + Math.max(1, Math.round(left / 60)) + ' 分钟';
    if (left < 48 * 3600) return '剩 ' + Math.round(left / 3600) + ' 小时';
    return '剩 ' + Math.floor(left / 86400) + ' 天';
  }

  function renderCalendar(evs, history) {
    if (calSub === 'done') {
      if (!history || !history.length) {
        body.innerHTML = '<div class="es-empty">还没有完成过的待办</div>';
        return;
      }
      body.innerHTML = history.map(function (h) {
        return '<div class="es-card es-hist-card" data-id="' + esc(h.id) + '">'
          + '<div class="es-title">✔ ' + esc(h.title) + '</div>'
          + '<div class="es-meta">原定 ' + esc(h.date) + ' · 完成于 ' + esc(h.done_date) + '</div>'
          + '<button class="es-undo">↩ 恢复</button>'
          + '</div>';
      }).join('');
      body.onclick = function (e) {
        var t = e.target && e.target.closest ? e.target : null;
        if (!t) return;
        var btn = t.closest('.es-undo');
        if (btn) {
          var card = btn.closest('.es-card');
          if (card) {
            post('/undone', { id: card.getAttribute('data-id') }, function () { refresh(true); });
          }
        }
      };
      return;
    }
    var html = '';
    if (!evs.length) {
      html += '<div class="es-empty">近期没有待办 🎉</div>';
    } else {
      html += evs.map(function (e) {
        var badge;
        if (e.overdue) {
          badge = '<span class="es-badge es-badge-overdue">❗ ' + esc(e.overdue_text || '已超时') + '</span>';
        } else if (e.days_left === 0) {
          badge = '<span class="es-badge">今天</span>';
        } else {
          badge = '<span class="es-badge' + (e.days_left <= 3 ? '' : ' es-badge-dim') + '">' + leftText(e.start) + '</span>';
        }
        return '<div class="es-card' + (e.overdue ? ' es-overdue' : '') + '" data-id="' + esc(e.id) + '">'
          + '<div class="es-title">📅 ' + esc(e.title) + '</div>'
          + '<div class="es-meta">' + esc(e.date) + (e.location ? ' · ' + esc(e.location) : '') + '</div>'
          + badge
          + '<button class="es-done2">✔ 完成</button>'
          + '</div>';
      }).join('');
    }
    if (history && history.length) {
      html += '<div class="es-hist-head">📜 最近完成</div>';
      html += history.map(function (h) {
        return '<div class="es-hist">✔ ' + esc(h.title) + '</div>';
      }).join('');
    }
    body.innerHTML = html;
    body.onclick = function (e) {
      var t = e.target && e.target.closest ? e.target : null;
      if (!t) return;
      var btn = t.closest('.es-done2');
      if (btn) {
        var card = btn.closest('.es-card');
        if (card) {
          post('/done', { id: card.getAttribute('data-id') }, function () { refresh(true); });
        }
        return;
      }
    };
  }

  function dateOptions() {
    var out = [];
    var now = new Date();
    for (var i = 0; i < 14; i++) {
      var d = new Date(now.getTime() + i * 86400000);
      var y = d.getFullYear();
      var m = ('0' + (d.getMonth() + 1)).slice(-2);
      var dd = ('0' + d.getDate()).slice(-2);
      var label = i === 0 ? '今天' : (i === 1 ? '明天' : (m + '-' + dd));
      out.push('<option value="' + y + '-' + m + '-' + dd + '">' + label + '</option>');
    }
    return out.join('');
  }

  function renderPlans(plans, today) {
    var addRow = '<div class="es-add">'
      + '<input type="text" id="es-plan-title" maxlength="60" placeholder="写个计划…（两周内）">'
      + '<select id="es-plan-date">' + dateOptions() + '</select>'
      + '<select id="es-plan-repeat"><option value="">单次</option>'
      + '<option value="daily">每天</option><option value="weekly">每周</option></select>'
      + '<button id="es-plan-add">添加</button></div>';
    if (!plans.length) {
      body.innerHTML = addRow + '<div class="es-empty">还没有计划，写一个吧 ✍️</div>';
    } else {
      body.innerHTML = addRow + plans.map(function (p) {
        var rep = p.repeat === 'daily' ? ' 🔁每天' : (p.repeat === 'weekly' ? ' 🔁每周' : '');
        var dateTxt = (p.date === today ? '今天' : p.date.slice(5)) + rep;
        if (!p.done && p.date < today) dateTxt = '过期 · ' + p.date.slice(5);
        return '<div class="es-plan' + (p.done ? ' es-done' : '') + '" data-id="' + esc(p.id) + '">'
          + '<input type="checkbox" class="es-check"' + (p.done ? ' checked' : '') + '>'
          + '<div class="es-plan-title">' + esc(p.title) + '</div>'
          + '<div class="es-plan-date">' + esc(dateTxt) + '</div>'
          + '<button class="es-del" title="删除">✕</button>'
          + '</div>';
      }).join('');
    }
    var addBtn = document.getElementById('es-plan-add');
    var ptInp = document.getElementById('es-plan-title');
    if (addBtn) {
      addBtn.onclick = function () {
        var ti = document.getElementById('es-plan-title');
        var dt = document.getElementById('es-plan-date');
        var rp = document.getElementById('es-plan-repeat');
        var title = (ti && ti.value || '').trim();
        if (!title) return;
        post('/plan-add', { title: title, date: dt && dt.value, repeat: rp && rp.value }, function () {
          refresh(true);
        });
      };
    }
    if (ptInp) {
      ptInp.onkeydown = function (ev) {
        if (ev.isComposing || ev.keyCode === 229) return;
        if (ev.key === 'Enter') {
          ev.preventDefault();
          if (addBtn) addBtn.click();
        }
      };
    }
    body.onclick = function (e) {
      var t = e.target && e.target.closest ? e.target : null;
      if (!t) return;
      var del = t.closest('.es-del');
      if (del) {
        var rowD = del.closest('.es-plan');
        if (rowD) post('/plan-del', { id: rowD.getAttribute('data-id') }, function () { refresh(true); });
        return;
      }
      var chk = t.closest('.es-check');
      if (chk) {
        var row = chk.closest('.es-plan');
        if (row) {
          post(chk.checked ? '/plan-done' : '/plan-undone',
            { id: row.getAttribute('data-id') }, function () { refresh(true); });
        }
        return;
      }
    };
  }

  function render(items) {
    if (!items.length) {
      body.innerHTML = '<div class="es-empty">暂无重要消息 🎉</div>';
      return;
    }
    body.innerHTML = items.map(function (i) {
      var isNew = i.created === lastNewest;
      if (i.kind === 'guide') {
        return '<div class="es-card es-guide' + (isNew ? ' es-new' : '') + '">'
          + (isNew ? '<div class="es-badge">NEW</div>' : '')
          + '<div class="es-title">📖 ' + esc(i.headline || '') + '</div>'
          + '<div class="sug es-pre">' + esc(i.suggestion || '') + '</div>'
          + (i.link ? '<div><a href="' + esc(i.link) + '" target="_blank">点此打开 ↗</a></div>' : '')
          + '</div>';
      }
      var det = (i.details || []).map(function (x) {
        return '<div class="det">📅 ' + esc(x) + '</div>';
      }).join('');
      var sug = i.suggestion ? '<div class="sug">💡 ' + esc(i.suggestion) + '</div>' : '';
      var link = i.link ? '<a href="' + esc(i.link) + '" target="_blank">打开原文 ↗</a>' : '';
      var att = (i.attachments || []).map(function (a) {
        return '<button class="es-att" data-path="' + esc(a.path) + '">📎 ' + esc(a.name) + '</button>';
      }).join(' ');
      return '<div class="es-card' + (isNew ? ' es-new' : '') + '" data-id="' + esc(i.id) + '">'
        + (isNew ? '<div class="es-badge">NEW</div>' : '')
        + '<div class="es-title">▶ ' + esc(i.headline || '') + '</div>'
        + '<div class="es-meta">' + esc(i.kind) + ' · ' + esc(i.sender) + ' · ' + esc(i.time) + '</div>'
        + '<div class="es-detail">'
        + '<div class="sub">' + esc(i.subject || '') + '</div>' + det + sug
        + (att ? '<div class="es-att-row">' + att + '</div>' : '')
        + '<div class="es-actions">'
        + '<button class="es-btn es-full-btn">📄 全文</button>'
        + '<button class="es-btn es-done-btn">✔ 关闭</button>'
        + '<span>' + link + '</span></div>'
        + '<div class="es-full"></div></div></div>';
    }).join('');
    body.onclick = function (e) {
      var t = e.target && e.target.closest ? e.target : null;
      if (!t) return;
      var attB = t.closest('.es-att');
      if (attB) {
        var p = attB.getAttribute('data-path');
        if (window.petBridge && window.petBridge.openPath) window.petBridge.openPath(p);
        return;
      }
      var doneB = t.closest('.es-done-btn');
      if (doneB) {
        var cardD = doneB.closest('.es-card');
        var idD = cardD && cardD.getAttribute('data-id');
        if (idD) {
          closedIds[idD] = true;
          cardD.style.display = 'none';
          post('/done', { id: idD });
        }
        return;
      }
      var fullB = t.closest('.es-full-btn');
      if (fullB) {
        var cardF = fullB.closest('.es-card');
        var idF = cardF && cardF.getAttribute('data-id');
        var box = cardF && cardF.querySelector('.es-full');
        if (!box || !idF) return;
        if (box.classList.contains('es-open')) {
          box.classList.remove('es-open');
          box.innerHTML = '';
          return;
        }
        box.innerHTML = '<div class="es-loading">读取中…</div>';
        box.classList.add('es-open');
        fetch(base + '/note?id=' + encodeURIComponent(idF))
          .then(function (r) { return r.json(); })
          .then(function (d) {
            box.innerHTML = '<pre class="es-full-text">' + esc((d.preview ? '【邮件全文】\n' + d.preview + '\n\n' : '') + d.text) + '</pre>';
          })
          .catch(function () { box.innerHTML = '<div class="es-loading">读取失败</div>'; });
        return;
      }
      var titleB = t.closest('.es-title');
      if (!titleB) return;
      var card = titleB.closest('.es-card');
      if (!card) return;
      var wasOpen = card.classList.contains('es-open');
      var all = body.querySelectorAll('.es-card.es-open');
      for (var k = 0; k < all.length; k++) all[k].classList.remove('es-open');
      if (!wasOpen) card.classList.add('es-open');
      titleB.textContent = (wasOpen ? '▶ ' : '▼ ') + titleB.textContent.slice(2);
    };
  }

  var lastTrKey = null;
  function renderTranslate(entries, active) {
    var key = (entries && entries.length ? entries[0].id : 'none') + '|' + (entries ? entries.length : 0);
    var keepInput = (key === lastTrKey) && window.__emailScrollOpen;
    var oldVal = '';
    var hadFocus = false;
    var oldInp = document.getElementById('es-tr-input');
    if (oldInp) {
      oldVal = oldInp.value;
      hadFocus = (document.activeElement === oldInp);
    }
    lastTrKey = key;
    var tools = '<div class="es-tr-tools">'
      + '<button id="es-tr-stop" class="' + (active ? 'on' : '') + '">'
      + (active ? '■ 结束翻译' : '▶ 开始翻译') + '</button>'
      + '<button id="es-tr-clear">🗑 清空</button></div>';
    var input = '<div class="es-add">'
      + '<input type="text" id="es-tr-input" maxlength="300" placeholder="输入英文，回车翻译…">'
      + '<button id="es-tr-go">翻译</button></div>';
    if (!entries.length) {
      body.innerHTML = input + tools + '<div class="es-empty">像小词典一样：输入英文 → 译文 + 音标</div>';
    } else {
      body.innerHTML = input + tools + entries.map(function (e) {
        return '<div class="es-tr">'
          + '<div class="es-tr-src">' + esc(e.src) + '</div>'
          + (e.ipa ? '<div class="es-tr-ipa">' + esc(e.ipa) + '</div>' : '')
          + '<div class="es-tr-zh">' + esc(e.zh) + '</div>'
          + '</div>';
      }).join('');
    }
    var inp = document.getElementById('es-tr-input');
    // 重建后保留未发送的输入与焦点（轮询重绘不再吞掉打字）
    if (inp && keepInput && (oldVal || hadFocus)) {
      inp.value = oldVal;
      if (hadFocus) {
        try { inp.focus(); } catch (e) { /* ignore */ }
      }
    }
    var go = document.getElementById('es-tr-go');
    function send() {
      var t = inp && inp.value.trim();
      if (!t) return;
      inp.value = '';
      post('/translate', { text: t });
    }
    if (go) go.onclick = send;
    if (inp) inp.onkeydown = function (ev) { if (ev.key === 'Enter') send(); };
    var stop = document.getElementById('es-tr-stop');
    if (stop) stop.onclick = function () {
      post(active ? '/translate-stop' : '/translate-start', {}, function () { refresh(true); });
    };
    var clr = document.getElementById('es-tr-clear');
    if (clr) clr.onclick = function () {
      post('/translate-clear', {}, function () { refresh(true); });
    };
  }

  function busyNow() {
    // 卷轴开着但不在邮件页（翻译/计划/待办）= 用户在干别的
    if (window.__emailScrollOpen && viewMode !== 'mails') return true;
    var s = window.__dshPetSprite;
    if (s && typeof s.inputBusy === 'function' && s.inputBusy()) return true;
    if (s && s.chatOpen) return true;
    return false;
  }

  function refresh(force) {
    if (viewMode === 'translate') {
      lastView = 'translate';
      fetch(base + '/translations')
        .then(function (r) { return r.json(); })
        .then(function (d) { renderTranslate(d.entries || [], d.active); })
        .catch(function () {});
      return;
    }
    if (viewMode === 'cal') {
      lastView = 'cal';
      fetch(base + '/calendar')
        .then(function (r) { return r.json(); })
        .then(function (d) { renderCalendar(d.events || [], d.history || []); })
        .catch(function () {});
      return;
    }
    if (viewMode === 'plans') {
      lastView = 'plans';
      fetch(base + '/plans')
        .then(function (r) { return r.json(); })
        .then(function (d) { renderPlans(d.plans || [], d.today); })
        .catch(function () {});
      return;
    }
    fetch(base + '/messages')
      .then(function (r) { return r.json(); })
      .then(function (d) {
        var items = (d.items || []).filter(function (i) { return !closedIds[i.id]; });
        var newest = null;
        for (var k = 0; k < items.length; k++) {
          var c = items[k].created;
          if (c != null && (newest === null || c > newest)) newest = c;
        }
        var changed = newest && newest !== lastNewest;
        var viewChanged = lastView !== 'mails';
        lastView = 'mails';
        if (changed) {
          var wasFirst = lastNewest === null;
          lastNewest = newest;
          render(items);
          var hasGuide = items.some(function (i) { return i.kind === 'guide'; });
          if (!wasFirst || hasGuide) {
            openScroll();
          } else if (!busyNow()) {
            // 女仆空闲：直接展开邮件卷轴给用户看；忙（如翻译中）则只让气泡提醒
            setTab('mails');
            openScroll();
          }
        } else if (viewChanged || force || !items.length) {
          render(items);
        }
      })
      .catch(function () { /* 服务器未就绪，下轮再试 */ });
  }

  function setTab(v) {
    viewMode = v;
    var tabs = document.querySelectorAll('.es-tab');
    for (var i = 0; i < tabs.length; i++) {
      tabs[i].classList.toggle('es-tab-on', tabs[i].getAttribute('data-v') === v);
    }
    refresh(true);
  }

  function positionScroll() {
    if (!el || !window.__emailScrollOpen) return;
    var spr = document.querySelector('.pet-sprite');
    if (!spr) return;
    var w = 460;
    var left = spr.offsetLeft + spr.offsetWidth / 2 - w / 2;
    // 面板展开后精灵常贴窗口右缘：把卷轴钳进窗口内，否则右半被裁、内容全挤左边
    var maxLeft = Math.max(8, window.innerWidth - w - 8);
    left = Math.min(Math.max(8, Math.round(left)), maxLeft);
    var top = spr.offsetTop + spr.offsetHeight + 8;
    el.style.left = left + 'px';
    el.style.top = Math.round(top) + 'px';
  }

  function openScroll() {
    if (!el) el = document.getElementById('email-scroll');
    if (!el) return;
    el.classList.add('open');
    window.__emailScrollOpen = true;
    positionScroll();
    var s = window.__dshPetSprite;
    if (s && s.syncInputBusy) {
      try { s.syncInputBusy(); } catch (e) { /* ignore */ }
    }
    if (posTimer === null) {
      posTimer = setInterval(positionScroll, 1500);
    }
  }

  window.__openTranslate = function () {
    setTab('translate');
    openScroll();
    post('/translate-start', {});
  };

  window.__toggleEmailScroll = function () {
    if (!el || !body) return;
    if (window.__emailScrollOpen) {
      el.classList.remove('open');
      window.__emailScrollOpen = false;
      if (posTimer !== null) { clearInterval(posTimer); posTimer = null; }
      var s = window.__dshPetSprite;
      if (s && s.syncInputBusy) {
        try { s.syncInputBusy(); } catch (e) { /* ignore */ }
      }
    } else {
      refresh(false);
      openScroll();
    }
  };

  window.addEventListener('DOMContentLoaded', function () {
    el = document.getElementById('email-scroll');
    body = document.getElementById('email-scroll-body');
    refresh(true);
    fetch(base + '/messages')
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (d.items && d.items.length) setTimeout(openScroll, 2500);
      })
      .catch(function () {});
    var tabs = document.querySelectorAll('.es-tab');
    for (var i = 0; i < tabs.length; i++) {
      tabs[i].addEventListener('click', function (e) {
        e.stopPropagation();
        setTab(this.getAttribute('data-v'));
      });
    }
    // 待办下拉：未完成 / 已完成
    var opts = document.querySelectorAll('.es-tab-opt');
    for (var k = 0; k < opts.length; k++) {
      opts[k].addEventListener('click', function (e) {
        e.stopPropagation();
        calSub = this.getAttribute('data-sub');
        var all = document.querySelectorAll('.es-tab-opt');
        for (var j = 0; j < all.length; j++) {
          all[j].classList.toggle('on', all[j].getAttribute('data-sub') === calSub);
        }
        viewMode = 'cal';
        var tabs2 = document.querySelectorAll('.es-tab');
        for (var m = 0; m < tabs2.length; m++) {
          tabs2[m].classList.toggle('es-tab-on', tabs2[m].getAttribute('data-v') === 'cal');
        }
        refresh(true);
      });
    }
  });
  setInterval(function () { refresh(false); }, 8000);
})();
