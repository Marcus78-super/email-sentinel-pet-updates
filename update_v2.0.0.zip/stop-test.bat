@echo off
echo Stopping TEST maid (only the test copy, your main maid stays)...
powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter \"Name='electron.exe' OR Name='pythonw.exe'\" | Where-Object { $_.CommandLine -match 'EmailSentinelPet' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"
echo Done.
pause
